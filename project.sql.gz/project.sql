-- Adminer 4.8.1 MySQL 5.5.5-10.6.12-MariaDB-0ubuntu0.22.04.1 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admins_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admins` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1,	'ahmad',	'ahmad@yahoo.com',	NULL,	'$2y$12$PesWtTbgOG8XeWUu3IGkd.pd0NjD8GH.jpAa6LMUdMrcuQmEEQnTa',	'rwBmhkqNHRIVEhMpxMiZGM1gVORsNLzGTdEPgzAhg7okfQu9yGuTiCBR45AQ',	'2023-12-23 07:13:09',	'2023-12-23 09:47:36'),
(2,	'dalia',	'dalia@yahoo.com',	NULL,	'$2y$12$FE0yHSsZue4vEniaQ0eGM.8q/.1hOvm3i9RBd5zVqS1mN.yoMZX..',	NULL,	'2023-12-23 07:29:31',	'2023-12-23 07:29:31'),
(3,	'othman',	'othman@yahoo.com',	NULL,	'$2y$12$qCbmIh9rIPhKI3P983OGPeNDMCuounMWDgWOwRgZhHGfE7PnytsJW',	NULL,	'2023-12-23 07:34:14',	'2023-12-23 07:34:14');

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1,	'2014_10_12_000000_create_users_table',	1),
(2,	'2014_10_12_100000_create_password_reset_tokens_table',	1),
(3,	'2019_08_19_000000_create_failed_jobs_table',	1),
(4,	'2019_12_14_000001_create_personal_access_tokens_table',	1),
(5,	'2023_12_20_134105_ceate_admins_table',	2);

DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `password_reset_tokens` (`email`, `token`, `created_at`) VALUES
('dalia@yahoo.com',	'$2y$12$/dFoTxOXHbkxbnQY15cKiuv1JFZvuKRuT2jQhYw59EdwTNkWDIclG',	'2023-12-23 09:35:28'),
('othman@yahoo.com',	'$2y$12$aO1VAVE2FpkQ1nIC52GEt.48NO1mzgFGEzK4UGmdn0vN6jyO.6NgC',	'2023-12-23 09:26:44');

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1,	'ahmad',	'ahmad@mail.com',	NULL,	'$2y$12$kfIs3f6V3t8MFhZljtxFrONWMUxby51J8Mi/y4joDel7dbnYlpz7m',	'uga9vGO0j1BsqcObLJwfvOkP6FGbj5eHOTI3WJ9Hss3nWV83fjBeF6DwbKdB',	'2023-12-18 07:52:30',	'2023-12-19 07:51:01'),
(2,	'othman',	'othman@mail.com',	NULL,	'$2y$12$qGYXUlNM4ra1LpwyWpktQekiTEtLgu.kUrZKaBAG2GmZo1ps57uPW',	NULL,	'2023-12-18 08:01:37',	'2023-12-18 08:01:37'),
(3,	'aisha',	'aisha@mail.com',	NULL,	'$2y$12$tDgJzHjKzT2bztj077zlee.DxTqPUKZlVzpaPaysoUkH4L4hKURtu',	NULL,	'2023-12-18 08:17:31',	'2023-12-18 08:17:31'),
(4,	'aikido',	'aikido@mail.com',	'2023-12-19 12:01:16',	'$2y$12$W52SOO/Do6w2feMp1o5VVe8qmNOil0fDQ68K7g0WUIUXexmTg/9yy',	NULL,	'2023-12-19 12:00:48',	'2023-12-19 12:01:16');

-- 2023-12-25 19:35:57
